package com.example.youtube.presentation.utils

object Constants {
    const val CHANNEL_ID = "UCWOA1ZGywLbqmigxE4Qlvuw"
    const val PART = "snippet,contentDetails"

}