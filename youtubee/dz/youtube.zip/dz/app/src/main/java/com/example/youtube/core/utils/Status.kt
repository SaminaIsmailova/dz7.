package com.example.youtube.core.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}